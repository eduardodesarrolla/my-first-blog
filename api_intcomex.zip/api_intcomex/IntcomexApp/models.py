from django.db import models

# Create your models here.
class Producto(models.Model):
    sku = models.CharField(max_length=50, primary_key=True)
    descripcion = models.CharField(max_length=250)
    cantidad = models.IntegerField()
    categoria = models.CharField(max_length=250)
    precio = models.IntegerField()
    marca = models.CharField(max_length=250)

    class Meta: #clase interna con representacion
        verbose_name = 'producto'
        verbose_name_plural = 'productos'

    def __str__(self):
        return self.sku
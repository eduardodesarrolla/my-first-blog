from django.shortcuts import render
from IntcomexApp.api import *
from IntcomexApp.conexion import *
from django.http import HttpResponse, HttpResponseNotFound
from django.shortcuts import redirect
from api_intcomex.settings import *
from django.contrib.auth.decorators import login_required

# Create your views here
@login_required
def intcomex(request):
    return render(request, "IntcomexApp/crud_intcomex.html")

def jumpseller(request):
    return render(request, "IntcomexApp/crud_jumpseller.html")

def insert_dash(string, index):
    return string[:index] + '.' + string[index:]
    
@login_required
def agregar(request):
    request.method=="POST"
    conexion = pymysql.connect(host='localhost',
                           user='root',
                           password='',
                           db='intcomex')
     
    with conexion.cursor() as cursor:
        
        consulta = "INSERT IGNORE INTO intcomexapp_producto(sku, descripcion, cantidad, categoria, precio, marca) VALUES (%s, %s, %s, %s, %s, %s);"
        for x in range(0,len(jsonToPython)):
            sku=jsonToPython[x]['Sku']
            descripcion=jsonToPython[x]['Description']
            cantidad=jsonToPython[x]['InStock']
            categoria=jsonToPython[x]['Category']['Description']
            antigua=round(((jsonToPython[x]['Price']['UnitPrice']*float(valor_dolar))*1.19)*1.10)
            otra=str(antigua)
            nueva=insert_dash(otra, -3)
            nueva1=nueva[:-3]
            precios =nueva1.replace(".", "990")
            try:
                precio = int(precios)
            except ValueError:
                print("")
            marca=jsonToPython[x]['Brand']['Description']
            rows = [(sku, descripcion, cantidad, categoria, precio, marca)]
            if cantidad > 5 and precio > 1:
                cursor.executemany(consulta, rows) 
            else:
                print("No hay lo suficiente") 
                print(rows)
        conexion.commit()
    
        conexion.close()
        
    return render(request, "IntcomexApp/crud_intcomex.html")
    
@login_required
def actualizar(request):
    request.method=="POST"
    
    conexion = pymysql.connect(host='localhost',
                           user='root',
                           password='',
                           db='intcomex')
    
    try:
        with conexion.cursor() as cursor:
             consulta = "UPDATE intcomexapp_producto SET CANTIDAD = %s, PRECIO = %s WHERE sku = %s;"
             for x in range(0,len(jsonToPython)):
                cantidad=jsonToPython[x]['InStock']
                antigua=round(((jsonToPython[x]['Price']['UnitPrice']*float(valor_dolar))*1.19)*1.10)
                otra=str(antigua)
                nueva=insert_dash(otra, -3)
                nueva1=nueva[:-3]
                precios =nueva1.replace(".", "990")
                try:
                    precio = int(precios)
                except ValueError:
                    print("")
                sku=jsonToPython[x]['Sku']
                cursor.execute(consulta, (cantidad, precio, sku))
		# No olvidemos hacer commit cuando hacemos un cambio a la BD
             conexion.commit()  
    finally:
             conexion.close()
    return render(request, "IntcomexApp/crud_intcomex.html")
    
@login_required
def agregar_j(request):
    cur = conexion.cursor()
    cur.execute( "SELECT sku, descripcion, cantidad, categoria, precio, marca FROM intcomexapp_producto Limit 10" )
    for sku, descripcion, cantidad, categoria, precio, marca in cur.fetchall():
        data = {"product": {
        "name": descripcion,
        "description": "a",
        "page_title": "la prueba",
        "meta_description": "esto es una prueba",
        "price": precio,
        "weight": 100,
        "stock": cantidad,
        "stock_unlimited": False,
        "sku": sku,
        "barcode": "",
        "google_product_category": "",
        "featured": False,
        "shipping_required": True,
        "status": "available",
        "package_format": "box",
        "length": 0,
        "width": 0,
        "height": 0,
        "diameter": 0,
        "permalink": "edu",
        "categories": [
        {
        "id": 2,
        "name": "intcomes",
        "parent_id": 0,
        "permalink": "edu"
        }
        ]
        }
        }
        #login = "5d03f313380c95128175b708390e7b92"
        #authtoken = "02bd20a4903bc44efc4298e2d84659ff"
        login = "04490abd35c41fcab3af6c7e5bd2f63f"
        authtoken = "f34b373f8974c16b5b945fc9a6c0f952"
        response1 = requests.post("https://api.jumpseller.com/v1/products.json?", params = {"login":login,"authtoken":authtoken}, headers= {"Content-Type":"application/json"}, data = json.dumps(data))
        # Definimos la cabecera y el diccionario con los datos
        dataJson1=response1.json
        #print(response.content)
        jsonToPython1 = json.loads(response1.content)
        if response1.status_code == 200:
            print (response1.text)
        print (sku, descripcion, cantidad, categoria, precio)
    conexion.close()
        
    return render(request, "IntcomexApp/crud_intcomex.html")
import pymysql

conexion = pymysql.connect(host='localhost',
                           user='root',
                           password='',
                           db='intcomex')